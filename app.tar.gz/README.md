# Wiglitcher App

For GLAMhack 2024..

To run the app:

Create a `.env` file and put the **Personal key** that you made on [Wikimedia API](https://api.wikimedia.org/wiki/Special:AppManagement) in there like this:

```
WIKIMEDIA_TOKEN=eyJ0eXAiOiJKV1QiLCJ...
```

Then you can:

```
flet run [app_directory]
```