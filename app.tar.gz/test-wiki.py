# Just a test
from mediawiki import *
print(get_random_images())